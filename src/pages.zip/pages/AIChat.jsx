import React, { useState, useRef, useEffect } from "react";
import "./AIChat.css";

const API_URL = "http://localhost:8000/ask";

export default function AIChat() {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([
    {
      role: "ai",
      text: "Hello! I'm ResQNet AI Assistant. Ask me about ResQNet, its features, APIs, and emergency support."
    }
  ]);
  const [loading, setLoading] = useState(false);

  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  }, [messages, loading]);

  const sendMessage = async (e) => {
    e.preventDefault();

    const question = message.trim();

    if (!question || loading) return;

    setMessages((prev) => [
      ...prev,
      { role: "user", text: question }
    ]);

    setMessage("");
    setLoading(true);

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          question: question
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.detail || `Server error: ${response.status}`
        );
      }

      setMessages((prev) => [
        ...prev,
        {
          role: "ai",
          text: data.answer || "No answer received."
        }
      ]);
    } catch (error) {
      console.error("AI chat error:", error);

      setMessages((prev) => [
        ...prev,
        {
          role: "error",
          text: error.message ||
            "Unable to connect to ResQNet AI. Please try again."
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => {
    if (loading) return;

    setMessages([
      {
        role: "ai",
        text: "Chat cleared. What would you like to know about ResQNet?"
      }
    ]);
  };

  return (
    <div className="ai-chat">
      <div className="ai-chat-header">
        <div>
          <h2>ResQNet AI Assistant</h2>
          <p>Ask questions about ResQNet and emergency support</p>
        </div>

        <button
          type="button"
          className="clear-chat"
          onClick={clearChat}
          disabled={loading}
        >
          Clear chat
        </button>
      </div>

      <div className="ai-chat-messages">
        {messages.map((item, index) => (
          <div
            key={index}
            className={`chat-message ${item.role}`}
          >
            <strong>
              {item.role === "user"
                ? "You"
                : item.role === "error"
                ? "Error"
                : "ResQNet AI"}
            </strong>

            <p>{item.text}</p>
          </div>
        ))}

        {loading && (
          <div className="chat-message ai">
            <strong>ResQNet AI</strong>
            <p>ResQNet AI is thinking...</p>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <form className="ai-chat-form" onSubmit={sendMessage}>
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your question..."
          disabled={loading}
        />

        <button
          type="submit"
          disabled={loading || !message.trim()}
        >
          {loading ? "Sending..." : "Send"}
        </button>
      </form>
    </div>
  );
}